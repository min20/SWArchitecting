var namespaceevent_handler =
[
    [ "EventHandler", "interfaceevent_handler_1_1_event_handler.html", "interfaceevent_handler_1_1_event_handler" ],
    [ "StreamSayHelloEventHandler", "classevent_handler_1_1_stream_say_hello_event_handler.html", "classevent_handler_1_1_stream_say_hello_event_handler" ],
    [ "StreamUpdateProfileEventHandler", "classevent_handler_1_1_stream_update_profile_event_handler.html", "classevent_handler_1_1_stream_update_profile_event_handler" ]
];