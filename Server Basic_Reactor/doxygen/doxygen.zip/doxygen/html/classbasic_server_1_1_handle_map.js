var classbasic_server_1_1_handle_map =
[
    [ "serialVersionUID", "classbasic_server_1_1_handle_map.html#ac3933c5d00781beb6cf93b4056f71cd4", null ]
];