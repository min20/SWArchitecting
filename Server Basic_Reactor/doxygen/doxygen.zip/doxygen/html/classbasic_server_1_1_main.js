var classbasic_server_1_1_main =
[
    [ "main", "classbasic_server_1_1_main.html#a0c7ee477ff533ef286ecf5a95148eda8", null ],
    [ "logger", "classbasic_server_1_1_main.html#a41d7399aaeba39a260abea976c89600b", null ],
    [ "PORT", "classbasic_server_1_1_main.html#af83ee27a3ec7ae49bcfed0bc78bd32ca", null ]
];