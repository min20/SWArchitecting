var interfaceevent_handler_1_1_event_handler =
[
    [ "getHandler", "interfaceevent_handler_1_1_event_handler.html#ada178635174014bad23584547462ac03", null ],
    [ "handleEvent", "interfaceevent_handler_1_1_event_handler.html#a4036ea3f27edd7df0caa57f42db27eed", null ]
];