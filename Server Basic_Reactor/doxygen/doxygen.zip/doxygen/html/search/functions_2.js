var searchData=
[
  ['handleevent',['handleEvent',['../interfaceevent_handler_1_1_event_handler.html#a4036ea3f27edd7df0caa57f42db27eed',1,'eventHandler.EventHandler.handleEvent()'],['../classevent_handler_1_1_stream_say_hello_event_handler.html#a859dc382ae8a35257af2149a9ed1c6b8',1,'eventHandler.StreamSayHelloEventHandler.handleEvent()'],['../classevent_handler_1_1_stream_update_profile_event_handler.html#a96b3a510c642a6848cff0afce54b7d8e',1,'eventHandler.StreamUpdateProfileEventHandler.handleEvent()']]]
];
