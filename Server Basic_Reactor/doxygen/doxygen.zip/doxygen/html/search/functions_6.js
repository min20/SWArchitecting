var searchData=
[
  ['threadpooldispatcher',['ThreadPoolDispatcher',['../classbasic_server_1_1_thread_pool_dispatcher.html#a26fda3271602b19753ce6e2d6d9b308a',1,'basicServer::ThreadPoolDispatcher']]]
];
