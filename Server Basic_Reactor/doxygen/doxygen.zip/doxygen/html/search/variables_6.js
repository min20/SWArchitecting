var searchData=
[
  ['serialversionuid',['serialVersionUID',['../classbasic_server_1_1_handle_map.html#ac3933c5d00781beb6cf93b4056f71cd4',1,'basicServer::HandleMap']]],
  ['serversocket',['serverSocket',['../classbasic_server_1_1_reactor.html#a2ddae2bb37e01fa74cfdd54b02ad00d0',1,'basicServer::Reactor']]],
  ['socket',['socket',['../classbasic_server_1_1_demultiplexer.html#ae73d9106d863dd9c902a2a941619056b',1,'basicServer::Demultiplexer']]]
];
