var searchData=
[
  ['max_5fdata_5fsize',['MAX_DATA_SIZE',['../classbasic_server_1_1_demultiplexer.html#a22d173243d9c6e9b3715330181f2d891',1,'basicServer::Demultiplexer']]]
];
