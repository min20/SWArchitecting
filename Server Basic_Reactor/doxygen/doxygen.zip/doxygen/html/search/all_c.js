var searchData=
[
  ['updateprofile',['updateProfile',['../classevent_handler_1_1_stream_update_profile_event_handler.html#a888b80c6db463e195fe9ebefc39c721e',1,'eventHandler::StreamUpdateProfileEventHandler']]]
];
