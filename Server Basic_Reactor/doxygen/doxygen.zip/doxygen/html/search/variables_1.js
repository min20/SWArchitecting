var searchData=
[
  ['handlemap',['handleMap',['../classbasic_server_1_1_demultiplexer.html#a9faf12f00a74f61936cff837b03609bd',1,'basicServer.Demultiplexer.handleMap()'],['../classbasic_server_1_1_reactor.html#a74841c32eee00227bbd43e8d016aad20',1,'basicServer.Reactor.handleMap()']]],
  ['header_5fsize',['HEADER_SIZE',['../classbasic_server_1_1_demultiplexer.html#a43686b9c044fc363ba7a9eae1f79120f',1,'basicServer::Demultiplexer']]]
];
