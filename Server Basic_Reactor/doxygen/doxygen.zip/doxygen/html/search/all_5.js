var searchData=
[
  ['logger',['logger',['../classbasic_server_1_1_demultiplexer.html#afea28eb5eb1482f56ce6b661232767b1',1,'basicServer.Demultiplexer.logger()'],['../classbasic_server_1_1_main.html#a41d7399aaeba39a260abea976c89600b',1,'basicServer.Main.logger()'],['../classevent_handler_1_1_stream_say_hello_event_handler.html#a9ce34e287f4621a4bd97e9b133e3a6f8',1,'eventHandler.StreamSayHelloEventHandler.logger()'],['../classevent_handler_1_1_stream_update_profile_event_handler.html#a90754ca06692e3fc5767403f29a567b8',1,'eventHandler.StreamUpdateProfileEventHandler.logger()']]]
];
