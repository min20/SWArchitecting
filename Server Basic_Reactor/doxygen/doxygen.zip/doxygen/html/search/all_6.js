var searchData=
[
  ['main',['Main',['../classbasic_server_1_1_main.html',1,'basicServer']]],
  ['main',['main',['../classbasic_server_1_1_main.html#a0c7ee477ff533ef286ecf5a95148eda8',1,'basicServer::Main']]],
  ['main_2ejava',['Main.java',['../_main_8java.html',1,'']]],
  ['max_5fdata_5fsize',['MAX_DATA_SIZE',['../classbasic_server_1_1_demultiplexer.html#a22d173243d9c6e9b3715330181f2d891',1,'basicServer::Demultiplexer']]]
];
