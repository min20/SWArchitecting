var searchData=
[
  ['data_5fsize',['DATA_SIZE',['../classevent_handler_1_1_stream_say_hello_event_handler.html#a7caabf3a748346a2161f5b671eacc4b4',1,'eventHandler.StreamSayHelloEventHandler.DATA_SIZE()'],['../classevent_handler_1_1_stream_update_profile_event_handler.html#a217e02fac4843d50927e5ebcb97baf0f',1,'eventHandler.StreamUpdateProfileEventHandler.DATA_SIZE()']]]
];
