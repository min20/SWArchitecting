var searchData=
[
  ['gethandler',['getHandler',['../interfaceevent_handler_1_1_event_handler.html#ada178635174014bad23584547462ac03',1,'eventHandler.EventHandler.getHandler()'],['../classevent_handler_1_1_stream_say_hello_event_handler.html#a2ff06320bb8ddd881d147d31a46d365b',1,'eventHandler.StreamSayHelloEventHandler.getHandler()'],['../classevent_handler_1_1_stream_update_profile_event_handler.html#a24bf455a312c225975d472516b4bb6f9',1,'eventHandler.StreamUpdateProfileEventHandler.getHandler()']]]
];
