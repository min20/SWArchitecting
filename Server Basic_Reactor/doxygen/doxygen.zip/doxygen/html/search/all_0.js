var searchData=
[
  ['basicserver',['basicServer',['../namespacebasic_server.html',1,'']]]
];
