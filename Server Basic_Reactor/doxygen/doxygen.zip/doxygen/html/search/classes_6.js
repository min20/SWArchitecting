var searchData=
[
  ['threadperdispatcher',['ThreadPerDispatcher',['../classbasic_server_1_1_thread_per_dispatcher.html',1,'basicServer']]],
  ['threadpooldispatcher',['ThreadPoolDispatcher',['../classbasic_server_1_1_thread_pool_dispatcher.html',1,'basicServer']]]
];
