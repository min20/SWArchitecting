var interfacebasic_server_1_1_dispatcher =
[
    [ "dispatch", "interfacebasic_server_1_1_dispatcher.html#a9a8d3e47b27a6161f8f39bf63fa9e198", null ]
];